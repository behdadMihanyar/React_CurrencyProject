const Footer = () => {
  return (
    <div className="w-full bg-amber-500 text-center bottom-0 fixed">
      ❤️ Designed by
    </div>
  );
};

export default Footer;
